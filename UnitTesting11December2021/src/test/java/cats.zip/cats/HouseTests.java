package cats;

import junit.framework.AssertionFailedError;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HouseTests {

    private Cat cat1;
    private Cat cat2;
    private Cat cat3;
    private Cat cat4;

    private House house;

    @Before
    public void setUp() {
        cat1 = new Cat("mike");
        cat2 = new Cat("mimi");
        cat3 = new Cat("sharo");
        cat4 = new Cat("pinki");

        house = new House("Star", 3);
        house.addCat(cat1);
        house.addCat(cat2);
    }

    @Test(expected = NullPointerException.class)
    public void test_create_house_with_null_name(){
        House house2 = new House(null, 10);
    }

    @Test
    public void test_getHouseName(){
        Assert.assertEquals("Star", house.getName());
    }

    @Test
    public void test_capacity() {
        Assert.assertEquals(3, house.getCapacity());
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_negative_capacity() {
        House house2 = new House("hello", -1);
    }

    @Test
    public void test_getCount() {
        Assert.assertEquals(2, house.getCount());
    }

    @Test
    public void test_addCat() {
        house.addCat(cat3);
        Assert.assertEquals(3, house.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_add_Cat_When_HouseIsFull() {
        house.addCat(cat3);
        house.addCat(cat4);

        Assert.assertEquals(2, house.getCount());
    }

    @Test
    public void test_removeCat() {
        house.removeCat("mike");
        Assert.assertEquals(1, house.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_removeNullCat() {
        house.removeCat("cat");
    }

    @Test
    public void test_caTForSale() {
        Assert.assertEquals(cat2, house.catForSale("mimi"));
        Assert.assertFalse(cat2.isHungry());
    }
    @Test(expected = IllegalArgumentException.class)
    public void test_CatForSale_When_Doesnt_Exist() {
        Assert.assertEquals(cat2, house.catForSale("cat"));
    }

}
